#knn2
import numpy as nm
import matplotlib.pyplot as mtp
import pandas as pd

data_set=pd.read_csv('Sleep_health_and_lifestyle_dataset.csv')
print(data_set)

from sklearn.preprocessing import OneHotEncoder
x=data_set.iloc[:,-1].values
la=OneHotEncoder()
data_set=la.fit_transform(data_set)
print(data_set)

# le=LabelEncoder()
# data_set['Gender'] = le.fit_transform(data_set['Gender'])
# print(data_set['Gender'])

x=data_set.iloc[:,[3,8]].values
print(x)
y=data_set.iloc[:,1].values
print(y)
#
# from sklearn.model_selection import train_test_split
# x_train,x_test,y_train,y_test=train_test_split(x,y,train_size=1/3,random_state=0)
# print(x_train)
# print(x_test)
# print(y_train)
# print(y_test)
#
# from sklearn.neighbors import KNeighborsClassifier
#from sklearn.preprocessing import StandardScaler
# fs=StandardScaler()
# x_train=fs.fit_transform(x_train)
# x_test=fs.transform(x_test)
# print(x_train)
# print(x_test)
# classifier=KNeighborsClassifier()
# classifier.fit(x_train,y_train)
# test_pred=classifier.predict(x_test)
# train_pred=classifier.predict(x_train)
# testdf=pd.DataFrame(test_pred,y_test)
# traindf=pd.DataFrame(train_pred,y_train)
# print(testdf)
# print(traindf)

# # from sklearn.metrics import confusion_matrix
# # cm=confusion_matrix(test_pred,y_test)
# # print(cm)
# #
# # from sklearn.metrics import accuracy_score
# # print(accuracy_score(test_pred,y_test))
# #
# # from sklearn.preprocessing import OrdinalEncoder
# # enc=OrdinalEncoder()
# # y=[['Male',1],['Female',0]]
# # y=enc.fit(y)
# # y=enc.categories_
# # y=enc.transform([['Male',1],['Female',0]])
# #
# #
