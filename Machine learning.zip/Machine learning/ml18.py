#Association
import numpy as np
import matplotlib.pyplot as mtp
import pandas as pd

data=pd.read_csv("Market_Basket_Optimisation.csv",header=None)
transaction=[]
for i in range(0,7501):
    transaction.append([str(data.values[i,j]) for j in range(0,20)])

from apyori import apriori
rules=apriori(transactions=transaction,min_support=0.0003,min_confidence=0.2,min_lift=3,min_length=2,max_length=2)

results=list(rules)
for item in results:
    pair = item[0]
    items = [x for x in pair]
    print("Rule: " + items[0] + " -> " + items[1])

    print("Support: " + str(item[1]))
    print("Confidence: " + str(item[2][0][2]))
    print("Lift: " + str(item[2][0][3]))
    print("=====================================")
