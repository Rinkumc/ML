import numpy as num
import matplotlib.pyplot as mtp
import pandas as pd

data_set = pd.read_csv("german_credit_data.csv")
print(data_set)

x = data_set.iloc[:,1].values
print(x)
print(x.shape)
x=x.reshape(1000,1)
print(x.shape)
print(x)

from sklearn.preprocessing import LabelEncoder
le=LabelEncoder()
data_set['Sex'] = le.fit_transform(data_set['Sex'])
print(data_set['Sex'])

y = data_set.iloc[:,2].values
print(y)
#
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x,y,test_size=1/3,random_state=0)
#feature scaling
from sklearn.preprocessing import StandardScaler
st_x = StandardScaler()
x_train = st_x.fit_transform(x_train)
x_test = st_x.transform(x_test)

from sklearn.naive_bayes import GaussianNB
classifier = GaussianNB()
print(classifier.fit(x_train,y_train))

y_pred = classifier.predict(x_test)
print(y_pred)
print("*******************************")

#create confusion matrix
from sklearn.metrics import confusion_matrix
Confusion_Matrix=confusion_matrix(y_test,y_pred)
print(Confusion_Matrix)

#check accuracy
from sklearn.metrics import accuracy_score
accuracy = accuracy_score(y_test,y_pred)
print(accuracy)