#Logistic Regression
import numpy as nm
import matplotlib.pyplot as mtp
import pandas as pd

data_set=pd.read_csv('User_Data.csv')
print(data_set)

x=data_set.iloc[:,[2,3]].values
print(x)
y=data_set.iloc[:,4]
print(y)

from sklearn.model_selection import train_test_split
x_train,x_test,y_train,y_test=train_test_split(x,y,train_size=1/3,random_state=0)
print(x_train)
print(x_test)
print(y_train)
print(y_test)

print("feature scaling")
from sklearn.preprocessing import StandardScaler
fs=StandardScaler()
x_train=fs.fit_transform(x_train)
x_test=fs.transform(x_test)
print(x_train)
print(x_test)

print("Predict")
from sklearn.linear_model import LogisticRegression
regressor=LogisticRegression(random_state=0)
regressor.fit(x_train,y_train)

test_pred=regressor.predict(x_test)
train_pred=regressor.predict(x_train)

testdf=pd.DataFrame(test_pred,y_test)
print(testdf)

traindf=pd.DataFrame(train_pred,y_train)
print(traindf)

print("Accuracy")
from sklearn.metrics import confusion_matrix
cm=confusion_matrix(y_test,test_pred)
print(cm)

from sklearn.metrics import accuracy_score
print(accuracy_score(y_test,test_pred))
