import numpy as nm
import matplotlib.pyplot as mtp
import pandas as pd

data_set=pd.read_csv('SynchronousMachine.csv')
print(data_set)

x=data_set.iloc[:,0].values
print(x)
print(x.shape)
xn=x.reshape(557,1)
print(xn)
print(xn.shape)
y=data_set.iloc[:,1].values
print(y)

from sklearn.model_selection import train_test_split
x_train,x_test,y_train,y_test=train_test_split(xn,y,test_size=1/3,random_state=0)
print(x_train)
print(x_test)
print(y_train)
print(y_test)

from sklearn.linear_model import LinearRegression
regressor=LinearRegression()
regressor.fit(x_train,y_train)

test_pred=regressor.predict(x_test)
train_pred=regressor.predict(x_train)

testdf=pd.DataFrame(test_pred,y_test)
print(testdf)

traindf=pd.DataFrame(train_pred,y_train)
print(traindf)

from sklearn.metrics import mean_squared_error
from math import sqrt
print(mean_squared_error(test_pred,y_test))
print(mean_squared_error(train_pred,y_train))
print(sqrt(mean_squared_error(test_pred,y_test)))
print(sqrt(mean_squared_error(train_pred,y_train)))

from sklearn.metrics import r2_score
print(r2_score(test_pred,y_test))
print(r2_score(train_pred,y_train))

from sklearn.metrics import mean_absolute_error
print(mean_absolute_error(test_pred,y_test))
print(mean_absolute_error(train_pred,y_train))
