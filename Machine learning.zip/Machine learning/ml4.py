#knn1
import numpy as nm
import matplotlib.pyplot as mtp
import pandas as pd

data_set=pd.read_csv('User_Data.csv')
print(data_set)

x=data_set.iloc[:,[2,3]].values
print(x)
y=data_set.iloc[:,4].values
print(y)

from sklearn.model_selection import train_test_split
x_train,x_test,y_train,y_test=train_test_split(x,y,train_size=1/3,random_state=0)
print(x_train)
print(x_test)
print(y_train)
print(y_test)

from sklearn.preprocessing import StandardScaler
fs=StandardScaler()
x_train=fs.fit_transform(x_train)
x_test=fs.transform(x_test)
print(x_train)
print(x_test)

from sklearn.neighbors import KNeighborsClassifier
classifier=KNeighborsClassifier()
classifier.fit(x_train,y_train)
test_pred=classifier.predict(x_test)
train_pred=classifier.predict(x_train)
testdf=pd.DataFrame(test_pred,y_test)
traindf=pd.DataFrame(train_pred,y_train)
print(testdf)
print(traindf)

from sklearn.metrics import confusion_matrix
cm=confusion_matrix(test_pred,y_test)
print(cm)

from sklearn.metrics import accuracy_score
print(accuracy_score(test_pred,y_test))


