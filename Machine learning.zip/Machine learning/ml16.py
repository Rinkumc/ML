#Dendrogram
import numpy as np
import matplotlib.pyplot as mtp
import pandas as pd

dataset =pd.read_csv("Mall_Customers.csv")
x=dataset.iloc[:,[3,4]].values

import scipy.cluster.hierarchy as shc
dendro=shc.dendrogram(shc.linkage(x,method="ward"))
mtp.title("Dendrogram plot")
mtp.ylabel("Eucledian distance")
mtp.xlabel("Customer")
mtp.show()

from sklearn.cluster import AgglomerativeClustering
hc=AgglomerativeClustering(n_clusters=5)
y_predict=hc.fit_predict(x)
print(y_predict)

mtp.scatter(x[y_predict == 0, 0], x[y_predict == 0, 1], s=100, c='blue', label='Cluster 1')  # for first cluster
mtp.scatter(x[y_predict == 1, 0], x[y_predict == 1, 1], s=100, c='green', label='Cluster 2')  # for second cluster
mtp.scatter(x[y_predict == 2, 0], x[y_predict == 2, 1], s=100, c='red', label='Cluster 3')  # for third cluster
mtp.scatter(x[y_predict == 3, 0], x[y_predict == 3, 1], s=100, c='cyan', label='Cluster 4')  # for fourth cluster
mtp.scatter(x[y_predict == 4, 0], x[y_predict == 4, 1], s=100, c='magenta', label='Cluster 5')  # for fifth cluster
# mtp.scatter(shc.cluster_centers_[:, 0], shc.cluster_centers_[:, 1], s=300, c='yellow', label='Centroid')
mtp.title("Dendrogram plot")
mtp.ylabel("Spending score")
mtp.xlabel("Clusters of customer")
mtp.legend()
mtp.show()